# AIWolfViewer
Viewer for AIWolf
