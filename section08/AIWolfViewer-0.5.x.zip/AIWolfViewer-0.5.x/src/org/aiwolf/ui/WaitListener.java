package org.aiwolf.ui;

public interface WaitListener {
	public void waitForNext();
}
